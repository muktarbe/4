public class Eagle extends Animal{


    public Eagle(String name, int age) {
        super(name, age);
    }

    public void eagle (){
        System.out.println(" я орел способная летать ");
    }

}
