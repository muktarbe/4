public class Turtle extends Animal{


    public Turtle(String name, int age) {
        super(name, age);
    }

    public  void turtle (){
        System.out.println(" я черепаха и я могу дышыть пад вадой и на суше ");
    }

}
