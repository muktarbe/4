// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Animal shark = new Shark(" акула ", 34);

        Animal turtle = new Turtle(" черепаха ", 22);

        Animal eagle = new Eagle(" орел ", 43);

        Animal[] animals = {shark, turtle, eagle};

        for (Animal ss : animals) {
            if (ss instanceof Shark) {
                Shark shark1 = (Shark) ss;
                shark1.animal();
                shark1.shark();
                System.out.println("------------------------------");
            }else if (ss instanceof Turtle) {
                    Turtle turtle1 = (Turtle) ss;
                    turtle1.animal();
                    turtle1.turtle();
                System.out.println("------------------------------");
            } else if (ss instanceof Eagle) {
                Eagle eagle1 = (Eagle) ss;
                eagle1.animal();
                eagle1.eagle();

            }
        }

    }
}
