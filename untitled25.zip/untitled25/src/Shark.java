public class Shark extends Animal{


    public Shark(String name, int age) {
        super(name, age);
    }

    public void shark() {
        System.out.println(" я быстро плаваю ");
    }
}
